package Logica;

import java.time.LocalDate;

public class Sistema {

    private Cuenta[] clientes;
    private Habitacion[] habitaciones;
    private Huesped[] huespedes;
    private Reserva[] reservas;
    private Pago[] pagos;

    private int conta;
    private int contaHabitacion;
    private int contaHuesped;
    private int contaReserva;
    private int contaPago;

    public Sistema() {
        clientes = new Cuenta[1];
        habitaciones = new Habitacion[1];
        huespedes = new Huesped[1];
        reservas = new Reserva[1];
        pagos = new Pago[1];

        conta = 0;
        contaHabitacion = 0;
        contaHuesped = 0;
        contaReserva = 0;
        contaPago = 0;
    }


    public boolean registrarCuenta(Cuenta cliente) {
        if (buscar(cliente.getUsuario()) != null) {
            return false;
        }
        clientes[conta] = cliente;
        conta++;
        redimensionar();
        return true;
    }

    public void redimensionar() {
        Cuenta[] aux = new Cuenta[conta + 1];
        for (int i = 0; i < conta; i++) {
            aux[i] = clientes[i];
        }
        clientes = aux;
    }

    public Cuenta inicioSesion(String usuario, String clave) {
        for (int i = 0; i < conta; i++) {
            if (clientes[i].getUsuario().equals(usuario) && clientes[i].getClave().equals(clave)) {
                return clientes[i];
            }
        }
        return null;
    }

    public Cuenta buscar(String usuario) {
        for (int i = 0; i < conta; i++) {
            if (clientes[i].getUsuario().equalsIgnoreCase(usuario)) {
                return clientes[i];
            }
        }
        return null;
    }


    public boolean registrarHabitacion(Habitacion habitacion) {
        if (buscarHabitacion(habitacion.getNumero()) != null) {
            return false;
        }
        habitaciones[contaHabitacion] = habitacion;
        contaHabitacion++;
        redimensionarHabitacion();
        return true;
    }

    public void redimensionarHabitacion() {
        Habitacion[] aux = new Habitacion[contaHabitacion + 1];
        for (int i = 0; i < contaHabitacion; i++) {
            aux[i] = habitaciones[i];
        }
        habitaciones = aux;
    }

    public Habitacion buscarHabitacion(String numero) {
        for (int i = 0; i < contaHabitacion; i++) {
            if (habitaciones[i].getNumero().equalsIgnoreCase(numero)) {
                return habitaciones[i];
            }
        }
        return null;
    }

    public boolean modificarHabitacion(Habitacion actualizada) {
        Habitacion existente = buscarHabitacion(actualizada.getNumero());
        if (existente == null) {
            return false;
        }
        existente.setTipo(actualizada.getTipo());
        existente.setCapacidad(actualizada.getCapacidad());
        existente.setPrecioNoche(actualizada.getPrecioNoche());
        existente.setEstado(actualizada.getEstado());
        return true;
    }

    public boolean eliminarHabitacion(String numero) {
        int pos = -1;
        for (int i = 0; i < contaHabitacion; i++) {
            if (habitaciones[i].getNumero().equalsIgnoreCase(numero)) {
                pos = i;
                break;
            }
        }
        if (pos == -1) {
            return false;
        }
        for (int i = pos; i < contaHabitacion - 1; i++) {
            habitaciones[i] = habitaciones[i + 1];
        }
        contaHabitacion--;
        habitaciones[contaHabitacion] = null;
        redimensionarHabitacion();
        return true;
    }

    public int totalHabitaciones() {
        return contaHabitacion;
    }

    public Habitacion obtenerHabitacion(int pos) {
        if (pos >= 0 && pos < contaHabitacion) {
            return habitaciones[pos];
        }
        return null;
    }

  
    public boolean registrarHuesped(Huesped huesped) {
        if (buscarHuesped(huesped.getDocumento()) != null) {
            return false;
        }
        huespedes[contaHuesped] = huesped;
        contaHuesped++;
        redimensionarHuesped();
        return true;
    }

    public void redimensionarHuesped() {
        Huesped[] aux = new Huesped[contaHuesped + 1];
        for (int i = 0; i < contaHuesped; i++) {
            aux[i] = huespedes[i];
        }
        huespedes = aux;
    }

    public Huesped buscarHuesped(String documento) {
        for (int i = 0; i < contaHuesped; i++) {
            if (huespedes[i].getDocumento().equalsIgnoreCase(documento)) {
                return huespedes[i];
            }
        }
        return null;
    }

    public boolean modificarHuesped(Huesped actualizado) {
        Huesped existente = buscarHuesped(actualizado.getDocumento());
        if (existente == null) {
            return false;
        }
        existente.setNombre(actualizado.getNombre());
        existente.setTelefono(actualizado.getTelefono());
        existente.setCorreo(actualizado.getCorreo());
        return true;
    }

    public boolean eliminarHuesped(String documento) {
        int pos = -1;
        for (int i = 0; i < contaHuesped; i++) {
            if (huespedes[i].getDocumento().equalsIgnoreCase(documento)) {
                pos = i;
                break;
            }
        }
        if (pos == -1) {
            return false;
        }
        for (int i = pos; i < contaHuesped - 1; i++) {
            huespedes[i] = huespedes[i + 1];
        }
        contaHuesped--;
        huespedes[contaHuesped] = null;
        redimensionarHuesped();
        return true;
    }

    public int totalHuespedes() {
        return contaHuesped;
    }

    public Huesped obtenerHuesped(int pos) {
        if (pos >= 0 && pos < contaHuesped) {
            return huespedes[pos];
        }
        return null;
    }

    
    public boolean registrarReserva(Reserva reserva) {
        if (buscarReserva(reserva.getCodigo()) != null) {
            return false;
        }
        reservas[contaReserva] = reserva;
        contaReserva++;
        redimensionarReserva();
        actualizarEstadoHabitacionPorReserva(reserva);
        return true;
    }

    public void redimensionarReserva() {
        Reserva[] aux = new Reserva[contaReserva + 1];
        for (int i = 0; i < contaReserva; i++) {
            aux[i] = reservas[i];
        }
        reservas = aux;
    }

    public Reserva buscarReserva(String codigo) {
        for (int i = 0; i < contaReserva; i++) {
            if (reservas[i].getCodigo().equalsIgnoreCase(codigo)) {
                return reservas[i];
            }
        }
        return null;
    }

    public boolean habitacionOcupadaEnReservaActiva(String numeroHabitacion, String codigoIgnorar) {
        for (int i = 0; i < contaReserva; i++) {
            Reserva r = reservas[i];
            if (codigoIgnorar != null && r.getCodigo().equalsIgnoreCase(codigoIgnorar)) {
                continue;
            }
            if (r.getHabitacion().equalsIgnoreCase(numeroHabitacion)
                    && (r.getEstado().equalsIgnoreCase("PENDIENTE") || r.getEstado().equalsIgnoreCase("CONFIRMADA"))) {
                return true;
            }
        }
        return false;
    }

    public boolean modificarReserva(Reserva actualizada) {
        Reserva existente = buscarReserva(actualizada.getCodigo());
        if (existente == null) {
            return false;
        }
        String habitacionAnterior = existente.getHabitacion();
        existente.setHuesped(actualizada.getHuesped());
        existente.setHabitacion(actualizada.getHabitacion());
        existente.setFechaEntrada(actualizada.getFechaEntrada());
        existente.setFechaSalida(actualizada.getFechaSalida());
        existente.setNoches(actualizada.getNoches());
        existente.setCostoTotal(actualizada.getCostoTotal());
        existente.setEstado(actualizada.getEstado());

        if (!habitacionAnterior.equalsIgnoreCase(actualizada.getHabitacion())) {
            Habitacion habAnt = buscarHabitacion(habitacionAnterior);
            if (habAnt != null && !habitacionOcupadaEnReservaActiva(habitacionAnterior, null)) {
                habAnt.setEstado("DISPONIBLE");
            }
        }
        actualizarEstadoHabitacionPorReserva(existente);
        return true;
    }

    public boolean eliminarReserva(String codigo) {
        int pos = -1;
        String numHab = null;
        for (int i = 0; i < contaReserva; i++) {
            if (reservas[i].getCodigo().equalsIgnoreCase(codigo)) {
                pos = i;
                numHab = reservas[i].getHabitacion();
                break;
            }
        }
        if (pos == -1) {
            return false;
        }
        for (int i = pos; i < contaReserva - 1; i++) {
            reservas[i] = reservas[i + 1];
        }
        contaReserva--;
        reservas[contaReserva] = null;
        redimensionarReserva();

        if (numHab != null) {
            Habitacion hab = buscarHabitacion(numHab);
            if (hab != null && !habitacionOcupadaEnReservaActiva(numHab, null)) {
                hab.setEstado("DISPONIBLE");
            }
        }
        return true;
    }

    private void actualizarEstadoHabitacionPorReserva(Reserva reserva) {
        Habitacion hab = buscarHabitacion(reserva.getHabitacion());
        if (hab != null) {
            if (reserva.getEstado().equalsIgnoreCase("PENDIENTE") || reserva.getEstado().equalsIgnoreCase("CONFIRMADA")) {
                hab.setEstado("OCUPADA");
            } else if (!habitacionOcupadaEnReservaActiva(hab.getNumero(), reserva.getCodigo())) {
                hab.setEstado("DISPONIBLE");
            }
        }
    }

    public int totalReservas() {
        return contaReserva;
    }

    public Reserva obtenerReserva(int pos) {
        if (pos >= 0 && pos < contaReserva) {
            return reservas[pos];
        }
        return null;
    }

    public boolean validarFechas(LocalDate entrada, LocalDate salida) {
        if (entrada == null || salida == null) {
            return false;
        }
        if (entrada.isBefore(LocalDate.now())) {
            return false;
        }
        if (!salida.isAfter(entrada)) {
            return false;
        }
        return true;
    }

    
    public boolean registrarPago(Pago pago) {
        if (buscarPago(pago.getCodigoPago()) != null) {
            return false;
        }
        pagos[contaPago] = pago;
        contaPago++;
        redimensionarPago();
        actualizarEstadoReservaPorPagos(pago.getCodigoReserva());
        return true;
    }

    public void redimensionarPago() {
        Pago[] aux = new Pago[contaPago + 1];
        for (int i = 0; i < contaPago; i++) {
            aux[i] = pagos[i];
        }
        pagos = aux;
    }

    public Pago buscarPago(String codigoPago) {
        for (int i = 0; i < contaPago; i++) {
            if (pagos[i].getCodigoPago().equalsIgnoreCase(codigoPago)) {
                return pagos[i];
            }
        }
        return null;
    }

    public boolean modificarPago(Pago actualizado) {
        Pago existente = buscarPago(actualizado.getCodigoPago());
        if (existente == null) {
            return false;
        }
        String reservaAnterior = existente.getCodigoReserva();
        existente.setCodigoReserva(actualizado.getCodigoReserva());
        existente.setNombreHuesped(actualizado.getNombreHuesped());
        existente.setValor(actualizado.getValor());
        existente.setMetodoPago(actualizado.getMetodoPago());
        existente.setEstado(actualizado.getEstado());
        existente.setFechaPago(actualizado.getFechaPago());

        actualizarEstadoReservaPorPagos(reservaAnterior);
        actualizarEstadoReservaPorPagos(actualizado.getCodigoReserva());
        return true;
    }

    public boolean eliminarPago(String codigoPago) {
        int pos = -1;
        String codReserva = null;
        for (int i = 0; i < contaPago; i++) {
            if (pagos[i].getCodigoPago().equalsIgnoreCase(codigoPago)) {
                pos = i;
                codReserva = pagos[i].getCodigoReserva();
                break;
            }
        }
        if (pos == -1) {
            return false;
        }
        for (int i = pos; i < contaPago - 1; i++) {
            pagos[i] = pagos[i + 1];
        }
        contaPago--;
        pagos[contaPago] = null;
        redimensionarPago();

        if (codReserva != null) {
            actualizarEstadoReservaPorPagos(codReserva);
        }
        return true;
    }

    public int totalPagos() {
        return contaPago;
    }

    public Pago obtenerPago(int pos) {
        if (pos >= 0 && pos < contaPago) {
            return pagos[pos];
        }
        return null;
    }

    public double calcularPagadoPorReserva(String codigoReserva) {
        double suma = 0.0;
        for (int i = 0; i < contaPago; i++) {
            if (pagos[i].getCodigoReserva().equalsIgnoreCase(codigoReserva)
                    && pagos[i].getEstado().equalsIgnoreCase("PAGADO")) {
                suma += pagos[i].getValor();
            }
        }
        return suma;
    }

    public double calcularIngresosTotales() {
        double total = 0.0;
        for (int i = 0; i < contaPago; i++) {
            if (pagos[i].getEstado().equalsIgnoreCase("PAGADO")) {
                total += pagos[i].getValor();
            }
        }
        return total;
    }

    private void actualizarEstadoReservaPorPagos(String codigoReserva) {
        Reserva res = buscarReserva(codigoReserva);
        if (res != null && res.getEstado().equalsIgnoreCase("PENDIENTE")) {
            double pagado = calcularPagadoPorReserva(codigoReserva);
            if (pagado >= res.getCostoTotal() && res.getCostoTotal() > 0) {
                res.setEstado("CONFIRMADA");
                actualizarEstadoHabitacionPorReserva(res);
            }
        }
    }
}